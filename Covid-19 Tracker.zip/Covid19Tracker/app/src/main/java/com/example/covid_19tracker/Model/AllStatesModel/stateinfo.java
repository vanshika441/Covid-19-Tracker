package com.example.covid_19tracker.Model.AllStatesModel;

public class stateinfo {
    String name;
    public stateinfo(String name) {
        this.name = name;
    }

    public String getName() {

        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

}

